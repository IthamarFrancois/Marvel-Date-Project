// API key
const API_KEY = "pk.eyJ1Ijoid2Vpcm1hbiIsImEiOiJja294aDRzbDUwZHE2Mm9xd2hlaW8wcWwxIn0.zl4VHM1kGXacC17nAqBAYw";
